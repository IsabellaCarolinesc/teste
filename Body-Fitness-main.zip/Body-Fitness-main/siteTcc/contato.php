<div class="container-fluid bg-light py-5">
        <div class="col-md-8 m-auto text-center">
        <h3 class="h3"><b>Nossas Lojas</b> <hr></h3>               
                    <h2 class="h2">1° Loja Física</h2>
                    <div id="mapid" style="width: 100%; height: 300px; padding-top: 20px;">
        
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3661.0261022718264!2d-46.50532759690188!3d-23.4234242385931!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce8b264f9fd863%3A0x1070da22039a5d64!2sAv.%20Silvestre%20Pires%20de%20Freitas%2C%20754%20-%20Jardim%20Paraiso%2C%20Guarulhos%20-%20SP%2C%2007144-000!5e0!3m2!1spt-BR!2sbr!4v1666895240237!5m2!1spt-BR!2sbr" width="100%" height="300px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                   
            </div>
    </div>


   

    <div class="container-fluid bg-light py-5">
        <div class="col-md-8 m-auto text-center">
            <h2 class="h2">2° Loja Física</h2>
            <hr>

            <a href="https://goo.gl/maps/mbJkWTEkCYkDMYXAA"><i class="fas fa-map-marker-alt fa-fw"></i></a> 

            Conheça a nossa segunda unidade, localizada no Brás.
            Piso superior, corredor G, Box 83 e 84
            <div id="mapid" style="width: 100%; height: 300px; align-content: center; padding-top: 20px;">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.7285212160177!2d-46.62012358440721!3d-23.542264766773805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5902a9319c57%3A0xca3af0610591d504!2sFeirinha%20da%20Conc%C3%B3rdia!5e0!3m2!1spt-BR!2sbr!4v1666896553704!5m2!1spt-BR!2sbr" width="100%" height="300px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           
            </div>
            </div>
            
            
    </div>