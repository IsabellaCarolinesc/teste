<section class="container py-5">
        <div class="row text-center pt-5 pb-3">
            <div class="col-lg-6 m-auto">
                <h1 class="h1">Sobre Nós</h1>
                <hr><p style="text-align:justify " >
                Acompanhando as tendências da moda feminina, a Body Fitness produz roupas 
                confortáveis, com estampas exclusivas e design diferenciado. Com tecidos de alta 
                 tecnológia, que permitem uma melhor respiração da pele, e recortes precisos que 
                 beneficiam o corpo durante o treino. E o melhor de tudo, com preços que cabe no seu 
                 bolso! Oferecemos aos nossos clientes uma grande variedade em roupas 
                 com qualidade, de nossa própria fabricação. Com diferentes modelos, para se encaixar em cada estilo! 
                 Temos: Camisetas, bermudas, tops fitness, bolsa térmica, mochila, leggins. 
                 Tudo isso para te acompanhar nas mais diversas atividades, como: Crossfit, boxe, 
                 corrida, bike, zumba, Muay Thai, spinning, musculação, pilates ou yoga e entre 
                 muitas outras atividades.
               </p><br>
               
                </div>
                <div class="col-md-4">
                    <img src="imagens/roupa.jpg" alt="About Hero" height="500px">
                </div>
            </div>
            <hr>
    <!-- Close Banner -->

    <!-- Start Section -->
    <section class="container py-5">
        <div class="row text-center pt-5 pb-3">
            <div class="col-lg-6 m-auto">
                <h1 class="h1">Nossos Serviços</h1>
                <hr>
                <p style="text-align:justify " >
                    Adquira peças de qualidade e excelência, conosco. 
                    Nossos produtos são produzidos com exclusividade e sempre pensamos no conforto e estilo dos clientes 
                    nas etapas de confecção.</p>

                    <br>
            </div>
        </div>
        <div class="row">

            <div class="col-md-6 col-lg-3 pb-5">
                <div class="h-100 py-5 services-icon-wap shadow">
                    <div class="h1 text-success text-center"><i class="fa fa-truck fa-lg"></i></div>
                    <h2 class="h5 mt-4 text-center">Lojas perto de você</h2>
                </div>
            </div>

            <div class="col-md-6 col-lg-3 pb-5">
                <div class="h-100 py-5 services-icon-wap shadow">
                    <div class="h1 text-success text-center"><i class="fas fa-exchange-alt"></i></div>
                    <h2 class="h5 mt-4 text-center">Devolução e Trocas</h2>
                </div>
            </div>

            <div class="col-md-6 col-lg-3 pb-5">
                <div class="h-100 py-5 services-icon-wap shadow">
                    <div class="h1 text-success text-center"><i class="fa fa-percent"></i></div>
                    <h2 class="h5 mt-4 text-center">Promoções</h2>
                </div>
            </div>

            <div class="col-md-6 col-lg-3 pb-5">
                <div class="h-100 py-5 services-icon-wap shadow">
                    <div class="h1 text-success text-center"><i class="fa fa-user"></i></div>
                    <h2 class="h5 mt-4 text-center">Atendimento ao Cliente</h2>
                </div>
            </div>
        </div>
    </section>
    <!-- End Section -->
   
     

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Brands-->